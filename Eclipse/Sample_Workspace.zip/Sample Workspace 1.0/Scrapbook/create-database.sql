drop database if exists `Sample`;
create database `Sample`;

create user 'sample-user'@'%' identified by password '*18CEC0B12394150D87DD1C214207742851272BA6';

create user 'sample-manager'@'%' identified by password '*18CEC0B12394150D87DD1C214207742851272BA6';

grant select, insert, update, delete 
	on `Sample`.* to 'sample-user'@'%';

grant select, insert, update, delete, create, drop, references, index, alter, 
        create temporary tables, lock tables, create view, create routine, 
        alter routine, execute, trigger, show view
    on `Sample`.* to 'sample-manager'@'%';
